CREATE VIEW commit_vire AS
  SELECT
    `databaseclass`.`deadline`.`id` AS `id`,
    `commit_daily`.`day`            AS `day`,
    count(0)                        AS `total`
  FROM `databaseclass`.`deadline`
    JOIN `databaseclass`.`commit_daily`
  WHERE ((`commit_daily`.`datetime` > `databaseclass`.`deadline`.`start_day`) AND
         (`commit_daily`.`datetime` < `databaseclass`.`deadline`.`end_day`))
  GROUP BY `databaseclass`.`deadline`.`id`, `commit_daily`.`day`;
