CREATE TRIGGER modifywritername
BEFORE INSERT ON platform_writer
FOR EACH ROW
  BEGIN
  IF NEW.writer_name NOT LIKE 'w_%' THEN
    SET NEW.writer_name = CONCAT( 'w_', NEW.writer_name);
  END IF ;
    END;
