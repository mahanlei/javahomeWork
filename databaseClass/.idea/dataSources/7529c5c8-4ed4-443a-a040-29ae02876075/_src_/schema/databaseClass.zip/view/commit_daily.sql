CREATE VIEW commit_daily AS
  SELECT
    `databaseclass`.`commit`.`sha`                               AS `sha`,
    `databaseclass`.`commit`.`datetime`                          AS `datetime`,
    date_format(`databaseclass`.`commit`.`datetime`, '%Y-%m-%d') AS `day`
  FROM `databaseclass`.`commit`;
