CREATE VIEW article_writer AS
  SELECT
    `writer`.`writer_name`                AS `writer_name`,
    `writer`.`writer_email`               AS `writer_email`,
    `article`.`content`                   AS `content`,
    sum(ifnull(`deal`.`deal_payment`, 0)) AS `totalPay`
  FROM `databaseclass`.`platform_article` `article`
    JOIN `databaseclass`.`platform_deal` `deal`
    JOIN `databaseclass`.`platform_writer` `writer`
  WHERE ((`article`.`writer_id` = `writer`.`writer_id`) AND (`article`.`article_id` = `deal`.`article_id`))
  GROUP BY `article`.`article_id`;
